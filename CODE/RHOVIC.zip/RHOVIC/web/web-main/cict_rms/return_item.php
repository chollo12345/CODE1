<?php
require 'db_connect.php';

// Check if database connection is successful
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch only items that are currently borrowed
$query = "
    SELECT DISTINCT inventory.id, inventory.item_name
    FROM inventory
    JOIN transactions ON inventory.id = transactions.item_id
    WHERE transactions.status = 'borrowed'
";
$result = mysqli_query($conn, $query);

// Check for query errors
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

// Fetch all borrowed items
$borrowed_items = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<div id="ReturnItem" class="tabcontent">
    <h2>Return Item</h2>
    <div class="form-container">
        <form method="POST" action="officer_dashboard.php">
            <select name="item_id" required>
                <option value="">Select Item</option>
                <?php if (!empty($borrowed_items)): ?>
                    <?php foreach ($borrowed_items as $item): ?>
                        <option value="<?php echo $item['id']; ?>">
                            <?php echo $item['item_name']; ?>
                        </option>
                    <?php endforeach; ?>
                <?php else: ?>
                    <option value="">No borrowed items</option>
                <?php endif; ?>
            </select>
            <input type="text" name="student_id" placeholder="Student ID" required>
            <input type="text" name="student_name" placeholder="Student Name" required>
            <button type="submit" name="return_item">Return Item</button>
        </form>
    </div>
</div>
