<?php
// Example backend script to handle adding/removing professors
include_once 'db.php';

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $professor_name = $_POST['professor_name'];

    if ($action === 'add') {
        // Add professor to the database
        $query = "INSERT INTO professors (name) VALUES ('$professor_name')";
        if (mysqli_query($conn, $query)) {
            echo "Professor added successfully!";
        } else {
            echo "Error adding professor!";
        }
    } elseif ($action === 'remove') {
        // Remove professor from the database
        $query = "DELETE FROM professors WHERE name = '$professor_name'";
        if (mysqli_query($conn, $query)) {
            echo "Professor removed successfully!";
        } else {
            echo "Error removing professor!";
        }
    }
}
?>
