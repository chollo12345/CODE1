<?php
// List all professors
include_once 'db.php';

$sql = "SELECT * FROM professors";
$result = mysqli_query($conn, $sql);

$professor_list = "";
while ($row = mysqli_fetch_assoc($result)) {
    $professor_list .= "<li>" . $row['name'] . "</li>";
}

echo $professor_list;
?>
