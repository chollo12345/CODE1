CREATE DATABASE IF NOT EXISTS faculty_eval_db;
USE faculty_eval_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('student', 'faculty', 'admin') NOT NULL
);

-- Feedback Table
CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  professor_name VARCHAR(100) NOT NULL,
  teaching INT NOT NULL CHECK (teaching BETWEEN 1 AND 5),
  teaching_comment TEXT,
  communication INT NOT NULL CHECK (communication BETWEEN 1 AND 5),
  communication_comment TEXT,
  punctuality INT NOT NULL CHECK (punctuality BETWEEN 1 AND 5),
  punctuality_comment TEXT,
  feedback TEXT NOT NULL,
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Professors Table (optional)
CREATE TABLE IF NOT EXISTS professors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL
);
