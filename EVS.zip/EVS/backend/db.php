<?php
// db.php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "faculty_eval_db"; // Change to your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set character set to UTF-8
mysqli_set_charset($conn, "utf8");
?>