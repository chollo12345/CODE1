<?php
// Fetch all feedback and ratings for admins
include_once 'db.php';

$sql = "SELECT * FROM feedback";
$result = mysqli_query($conn, $sql);
$feedback_data = [];

while ($row = mysqli_fetch_assoc($result)) {
    $feedback_data[] = $row;
}

echo json_encode($feedback_data);
?>
