<?php
include 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

$sql = "SELECT * FROM users WHERE username=? AND role=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $role);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    if (password_verify($password, $row['password'])) {
        if ($role === 'student') {
            header("Location: ../frontend/student_dashboard.html");
        } elseif ($role === 'faculty') {
            header("Location: ../frontend/faculty_dashboard.html");
        } elseif ($role === 'admin') {
            header("Location: ../frontend/admin_dashboard.html");
        }
    } else {
        echo "Invalid password.";
    }
} else {
    echo "User not found.";
}
?>
